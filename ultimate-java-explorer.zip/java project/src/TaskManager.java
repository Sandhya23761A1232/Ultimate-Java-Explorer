public class TaskManager {
    public static void run() {
        System.out.println("\n=== Task Manager ===");
        System.out.println("Active Threads: ");
        Thread.getAllStackTraces().keySet().forEach(thread -> 
            System.out.println("- " + thread.getName() + " (State: " + thread.getState() + ")")
        );
        System.out.println("Returning to main menu...");
    }
}
