import java.util.*;

public class VirtualOS {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1 -> FileExplorer.run();
                case 2 -> TaskManager.run();
                case 3 -> Calculator.run();
               
                case 4 -> NetworkMonitor.run();
                case 5 -> AIChatAssistant.run();
                case 6 -> exitSystem();
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\n=== Welcome to Ultimate Java Explorer ===");
        System.out.println("1. File Explorer");
        System.out.println("2. Task Manager");
        System.out.println("3. Calculator");
        System.out.println("4. NetworkMonitor");
        System.out.println("5. AIChatAssistant");
        System.out.println("6. Exit");
        System.out.print("Choose an option: ");
    }

    private static int getUserChoice() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static void exitSystem() {
        System.out.println("Exiting... Thank you for using Ultimate Java Explorer!");
        System.exit(0);
    }
}
