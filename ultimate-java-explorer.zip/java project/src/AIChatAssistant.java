import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class AIChatAssistant {
    private static final String API_KEY = "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"; 
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private static final Scanner scanner = new Scanner(System.in);

    public static void run() {
        System.out.println("\nWelcome to AI Chat Assistant! Type 'exit' to return to Virtual OS.");
        while (true) {
            System.out.print("\nYou: ");
            String userQuery = scanner.nextLine();

            if (userQuery.equalsIgnoreCase("exit")) {
                System.out.println("Exiting AI Chat Assistant...");
                break;
            }

            String response = getAIResponse(userQuery);
            System.out.println("\nAI: " +response);
        }
    }

    private static String getAIResponse(String query) {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String jsonInput = "{"
                    + "\"model\": \"gpt-3.5-turbo\","
                    + "\"messages\": [{\"role\": \"user\", \"content\": \"" + query + "\"}],"
                    + "\"max_tokens\": 100"
                    + "}";

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInput.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
                os.flush();
            }

            int responseCode = conn.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                return "Error: OpenAI API returned response code " + responseCode;
            }

            StringBuilder response = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }

            return parseResponse(response.toString());

        } catch (Exception e) {
            return "Error connecting to AI: " + e.getMessage();
        }
    }

    private static String parseResponse(String jsonResponse) {
        int index = jsonResponse.indexOf("\"content\":\"");
        if (index != -1) {
            int start = index + 10;
            int end = jsonResponse.indexOf("\"", start);
            return jsonResponse.substring(start, end).replace("\\n", "\n").replace("\\\"", "\"");
        }
        return "AI Response could not be parsed.";
    }
}