import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class NetworkMonitor {
    public static void run() {
        System.out.println("\n Network Monitor Started...");
        checkInternetConnectivity();
        measureInternetSpeed();
    }

    // Check if the system is connected to the internet or not
    private static void checkInternetConnectivity() {
        try {
            InetAddress address = InetAddress.getByName("google.com");
            if (address.isReachable(3000)) {
                System.out.println(" Internet Status: Connected");
                System.out.println(" IP Address: " + getPublicIP());
            } else {
                System.out.println("Internet Status: Disconnected");
            }
        } catch (Exception e) {
            System.out.println(" Unable to check internet status: " + e.getMessage());
        }
    }

    // Get Public IP Address
    private static String getPublicIP() {
        try {
            URL url = new URL("https://checkip.amazonaws.com/");
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            return br.readLine();
        } catch (Exception e) {
            return "Unknown";
        }
    }

    // Measure Download Speed
    private static void measureInternetSpeed() {
        System.out.println("\n Measuring Internet Speed...");

        try {
            long startTime = System.nanoTime();

            //speed test
            URL url = new URL("https://www.speedtest.net/speedtest-config.php");

            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

            while (in.read() != -1) { /* Downloading... */ }
            in.close();

            long endTime = System.nanoTime();
            double seconds = TimeUnit.NANOSECONDS.toSeconds(endTime - startTime);
            double downloadSpeed = (100.0 / seconds); // MBps

            System.out.printf(" Download Speed: %.2f MBps\n", downloadSpeed);
        } catch (Exception e) {
            System.out.println(" Error measuring speed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        run();
    }
}
