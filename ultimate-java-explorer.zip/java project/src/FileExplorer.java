import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileExplorer {
    private static Scanner scanner = new Scanner(System.in);

    public static void run() {
        while (true) {
            System.out.println("\n=== File Explorer ===");
            System.out.println("1. List Files");
            System.out.println("2. Create File");
            System.out.println("3. Delete File");
            System.out.println("4. Read File");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1 -> listFiles();
                case 2 -> createFile();
                case 3 -> deleteFile();
                case 4 -> readFile();
                case 5 -> { return; }
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }

    private static void listFiles() {
        File folder = new File(".");
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                System.out.println((file.isDirectory() ? "[DIR] " : "[FILE] ") + file.getName());
            }
        }
    }

    private static void createFile() {
        System.out.print("Enter filename: ");
        String filename = scanner.nextLine();
        try {
            File file = new File(filename);
            if (file.createNewFile()) {
                System.out.println("File created: " + filename);
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }

    private static void deleteFile() {
        System.out.print("Enter filename to delete: ");
        String filename = scanner.nextLine();
        File file = new File(filename);
        if (file.delete()) {
            System.out.println("Deleted: " + filename);
        } else {
            System.out.println("File not found.");
        }
    }

    private static void readFile() {
        System.out.print("Enter filename to read: ");
        String filename = scanner.nextLine();
        File file = new File(filename);
        if (file.exists()) {
            try (Scanner fileReader = new Scanner(file)) {
                while (fileReader.hasNextLine()) {
                    System.out.println(fileReader.nextLine());
                }
            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
            }
        } else {
            System.out.println("File not found.");
        }
    }
}
